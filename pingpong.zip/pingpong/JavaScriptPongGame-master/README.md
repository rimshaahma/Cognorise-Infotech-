# JavaScriptPongGame
My first JavaScript project, recreating a simple Pong game with basic AI Movement

Link to play
https://rion5.github.io/JavaScriptPongGame/

![capture](https://user-images.githubusercontent.com/31965265/36637920-310d99c0-19b4-11e8-8712-dde1776d6a7a.PNG)
