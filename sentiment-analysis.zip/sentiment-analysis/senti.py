# Import the required library
from textblob import TextBlob

# Function to analyze the sentiment of text
def analyze_sentiment(text):
    try:
        # Create a TextBlob object
        blob = TextBlob(text)

        # Get the polarity and subjectivity
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity

        # Classify the sentiment based on polarity
        if polarity > 0:
            sentiment = "Positive"
        elif polarity < 0:
            sentiment = "Negative"
        else:
            sentiment = "Neutral"

        # Return results
        return {
            "Sentiment": sentiment,
            "Polarity": polarity,
            "Subjectivity": subjectivity
        }
    except Exception as e:
        return {"Error": str(e)}

# Main program to interact with the user
def main():
    print("Welcome to the Sentiment Analysis Tool!")
    print("Enter text (multiple sentences allowed) to analyze sentiment.\n")

    while True:
        # Take user input
        text = input("Enter your text (or type 'exit' to quit): ")

        if text.lower() == 'exit':
            print("Goodbye!")
            break
        
        # Analyze the sentiment of the input text
        result = analyze_sentiment(text)

        # Check if there was an error during analysis
        if "Error" in result:
            print(f"Error analyzing sentiment: {result['Error']}")
        else:
            # Display the results
            print("\nSentiment Analysis Results:")
            print(f"  Sentiment: {result['Sentiment']}")
            print(f"  Polarity (Strength of sentiment): {result['Polarity']}")
            print(f"  Subjectivity (0 = fact, 1 = opinion): {result['Subjectivity']}\n")
        
        # Continue or quit based on user input
        print("--------------------------------------------------\n")

if __name__ == "__main__":
    main()
